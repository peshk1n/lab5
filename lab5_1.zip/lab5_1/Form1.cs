using System;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace lab5_1
{
    public partial class Form1 : Form
    {
        private LSystem lSystem;
        private List<PointF> points;
        private List<LineSegment> branches;
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            points = new List<PointF>();
            branches = new List<LineSegment>();
            pictureBox.BackColor = Color.White;

            pictureBox.Paint += pictureBox_Paint;
            this.Resize += form_Resize;
        }

        private void form_Resize(object sender, EventArgs e)
        {
            ScalePoints();
            ScaleLineSegments();
            pictureBox.Invalidate();
        }

        private void btnLoadLSystem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                lSystem = new LSystem(ofd.FileName);
            }
        }

        private void btnDrawFractal_Click(object sender, EventArgs e)
        {
            if (lSystem == null) return;

            int iterations = int.Parse(txtIterations.Text);
            string result = lSystem.Generate(iterations);

            float currentAngle = lSystem.Direction;
            PointF currentPos = new PointF(pictureBox.Width / 2, pictureBox.Height);
            Stack<(PointF, float)> positionStack = new Stack<(PointF, float)>(); ;

            points.Clear();
            branches.Clear();
            float stepSize = 1; 

            foreach (var symbol in result)
            {
                switch (symbol)
                {
                    case 'F': 
                        var newPos = new PointF(
                            currentPos.X + stepSize * (float)Math.Cos(currentAngle * Math.PI / 180),
                            currentPos.Y + stepSize * (float)Math.Sin(currentAngle * Math.PI / 180));
                        points.Add(currentPos);
                        points.Add(newPos);
                        currentPos = newPos;
                        break;

                    case '+': 
                        currentAngle += lSystem.Angle;
                        break;

                    case '-': 
                        currentAngle -= lSystem.Angle;
                        break;

                    case '[': 
                        positionStack.Push((currentPos, currentAngle));
                        break;

                    case ']': 
                        if(positionStack.Count > 0)
                        {
                            var state = positionStack.Pop();
                            currentPos = state.Item1;
                            currentAngle = state.Item2;
                        }
                        break;
                }
            }

            ScalePoints();

            pictureBox.Invalidate(); 
        }


        private void btnDrawTree_Click(object sender, EventArgs e)
        {
            if (lSystem == null) return;

            int iterations = int.Parse(txtIterations.Text);
            string result = lSystem.Generate(iterations);

            float currentAngle = lSystem.Direction;
            PointF currentPos = new PointF(pictureBox.Width / 2, pictureBox.Height);
            Stack<(PointF, float)> positionStack = new Stack<(PointF, float)>(); ;

            points.Clear();
            branches.Clear();
            float stepSize = 1;

            int currentDepth = 0;

            Color startColor = Color.Brown;
            Color endColor = Color.Green;

            float startThickness = 10.0f;
            float endThickness = 1.0f;

            foreach (var symbol in result)
            {
                switch (symbol)
                {
                    case 'F':
                        var newPos = new PointF(
                            currentPos.X + stepSize * (float)Math.Cos(currentAngle * Math.PI / 180),
                            currentPos.Y + stepSize * (float)Math.Sin(currentAngle * Math.PI / 180));

                        float t = (float)currentDepth / iterations;
                        float thickness = InterpolateThickness(startThickness, endThickness, t);
                        Color lineColor = InterpolateColor(startColor, endColor, t);

                        branches.Add(new LineSegment
                        {
                            Start = currentPos,
                            End = newPos,
                            Thickness = thickness,
                            Color = lineColor
                        });

                        currentPos = newPos;
                        break;

                    case '+':
                        currentAngle += lSystem.Angle + GetRandomAngleOffset();
                        break;

                    case '-':
                        currentAngle -= lSystem.Angle + GetRandomAngleOffset();
                        break;

                    case '[':
                        currentDepth++;
                        positionStack.Push((currentPos, currentAngle));
                        break;

                    case ']':
                        if(positionStack.Count() > 0)
                        {
                            var state = positionStack.Pop();
                            currentPos = state.Item1;
                            currentAngle = state.Item2;
                            currentDepth--;
                        }
                        break;
                }
            }

            ScaleLineSegments();

            pictureBox.Invalidate();
        }

        private float GetRandomAngleOffset()
        {
            return (float)(random.NextDouble() * 20 - 10); 
        }

        private float InterpolateThickness(float startThickness, float endThickness, float t)
        {
            return startThickness * (1 - t) + endThickness * (t - 1);
        }

        private Color InterpolateColor(Color startColor, Color endColor, float t)
        {
            int r = (int)(startColor.R + (endColor.R - startColor.R) * t);
            int g = (int)(startColor.G + (endColor.G - startColor.G) * t);
            int b = (int)(startColor.B + (endColor.B - startColor.B) * t);

            r = Math.Max(0, Math.Min(255, r));
            g = Math.Max(0, Math.Min(255, g));
            b = Math.Max(0, Math.Min(255, b));

            return Color.FromArgb(r, g, b);
        }


        private void ScalePoints()
        {
            if (points.Count == 0) return;

            float pictureBoxWidth = pictureBox.Width + 170;

            float minX = points.Min(p => p.X);
            float minY = points.Min(p => p.Y);
            float maxX = points.Max(p => p.X);
            float maxY = points.Max(p => p.Y);

            float scaleX = pictureBoxWidth / (maxX - minX);
            float scaleY = pictureBox.Height / (maxY - minY);
            float scale = Math.Min(scaleX, scaleY);

            float offsetX = (pictureBoxWidth - (maxX - minX) * scale) / 2;
            float offsetY = (pictureBox.Height - (maxY - minY) * scale) / 2;

            for (int i = 0; i < points.Count; i++)
            {
                points[i] = new PointF(
                    (points[i].X - minX) * scale + offsetX,
                    (points[i].Y - minY) * scale + offsetY
                );
            }
        }

        private void ScaleLineSegments()
        {
            if (branches.Count == 0) return;

            float pictureBoxWidth = pictureBox.Width + 170;

            float minX = branches.Min(ls => Math.Min(ls.Start.X, ls.End.X));
            float minY = branches.Min(ls => Math.Min(ls.Start.Y, ls.End.Y));
            float maxX = branches.Max(ls => Math.Max(ls.Start.X, ls.End.X));
            float maxY = branches.Max(ls => Math.Max(ls.Start.Y, ls.End.Y));

            float scaleX = pictureBoxWidth / (maxX - minX);
            float scaleY = pictureBox.Height / (maxY - minY);
            float scale = Math.Min(scaleX, scaleY);

            float offsetX = (pictureBoxWidth - (maxX - minX) * scale) / 2;
            float offsetY = (pictureBox.Height - (maxY - minY) * scale) / 2;

            for (int i = 0; i < branches.Count; i++)
            {
                branches[i].Start = new PointF(
                    (branches[i].Start.X - minX) * scale + offsetX,
                    (branches[i].Start.Y - minY) * scale + offsetY
                );
                branches[i].End = new PointF(
                    (branches[i].End.X - minX) * scale + offsetX,
                    (branches[i].End.Y - minY) * scale + offsetY
                );
            }
        }


        private void pictureBox_Paint(object sender, PaintEventArgs e)
        {
            if (points.Count > 2)
            {
                using (Pen pen = new Pen(Color.Black))
                {
                    for (int i = 0; i < points.Count - 1; i += 2)
                    {
                        e.Graphics.DrawLine(pen, points[i], points[i + 1]);
                    }
                }
            }

            if(branches.Count > 2)
            {
                foreach (var segment in branches)
                {
                    using (Pen pen = new Pen(segment.Color, segment.Thickness))
                    {
                        pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                        pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                        e.Graphics.DrawLine(pen, segment.Start, segment.End);
                    }
                }
            }
        }
    }


    public class LineSegment
    {
        public PointF Start { get; set; }
        public PointF End { get; set; }
        public float Thickness { get; set; }
        public Color Color { get; set; }
    }

    public class LSystem
    {
        private Random random;
        public string Axiom { get; set; }
        public float Angle { get; set; }
        public float Direction { get; set; }
        public Dictionary<char, string> Rules { get; set; }

        public LSystem(string filename)
        {
            Rules = new Dictionary<char, string>();
            LoadFromFile(filename);
            random = new Random();
        }

        private void LoadFromFile(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            var header = lines[0].Split(' ');
            Axiom = header[0];        
            Angle = float.Parse(header[1]);
            Direction = float.Parse(header[2]);

            for (int i = 1; i < lines.Length; i++)
            {
                var rule = lines[i].Split("->");
                if (rule.Length == 2)
                {
                    Rules[rule[0].Trim()[0]] = rule[1].Trim();
                }
            }
        }

        public string Generate(int iterations)
        {
            string current = Axiom; 
            for (int i = 0; i < iterations; i++)
            {
                StringBuilder next = new StringBuilder();
                foreach (var c in current)
                {
                    if (Rules.ContainsKey(c))
                    {
                        next.Append(Rules[c]);
                    }
                    else
                    {
                        if(c == '@')
                        {
                            var keys = Rules.Keys.ToArray();
                            next.Append(Rules[keys[random.Next(keys.Length)]]);
                        }
                        else
                        {
                            next.Append(c.ToString());
                        }
                    }
                }
                current = next.ToString(); 
            }
            return current;
        }
    }
}
