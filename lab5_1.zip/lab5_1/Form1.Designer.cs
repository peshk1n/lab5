﻿namespace lab5_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadLSystem = new System.Windows.Forms.Button();
            this.btnDrawFractal = new System.Windows.Forms.Button();
            this.txtIterations = new System.Windows.Forms.TextBox();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDrawTree = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLoadLSystem
            // 
            this.btnLoadLSystem.Location = new System.Drawing.Point(10, 12);
            this.btnLoadLSystem.Name = "btnLoadLSystem";
            this.btnLoadLSystem.Size = new System.Drawing.Size(150, 50);
            this.btnLoadLSystem.TabIndex = 1;
            this.btnLoadLSystem.Text = "Загрузить L-систему";
            this.btnLoadLSystem.UseVisualStyleBackColor = true;
            this.btnLoadLSystem.Click += new System.EventHandler(this.btnLoadLSystem_Click);
            // 
            // btnDrawFractal
            // 
            this.btnDrawFractal.Location = new System.Drawing.Point(10, 67);
            this.btnDrawFractal.Name = "btnDrawFractal";
            this.btnDrawFractal.Size = new System.Drawing.Size(150, 50);
            this.btnDrawFractal.TabIndex = 2;
            this.btnDrawFractal.Text = "Нарисовать фрактал";
            this.btnDrawFractal.UseVisualStyleBackColor = true;
            this.btnDrawFractal.Click += new System.EventHandler(this.btnDrawFractal_Click);
            // 
            // txtIterations
            // 
            this.txtIterations.Location = new System.Drawing.Point(10, 210);
            this.txtIterations.Name = "txtIterations";
            this.txtIterations.Size = new System.Drawing.Size(150, 27);
            this.txtIterations.TabIndex = 3;
            this.txtIterations.Text = "5";
            // 
            // pictureBox
            // 
            this.pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(1062, 703);
            this.pictureBox.TabIndex = 4;
            this.pictureBox.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnDrawTree);
            this.panel1.Controls.Add(this.btnLoadLSystem);
            this.panel1.Controls.Add(this.btnDrawFractal);
            this.panel1.Controls.Add(this.txtIterations);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(170, 703);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 187);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Итерации:";
            // 
            // btnDrawTree
            // 
            this.btnDrawTree.Location = new System.Drawing.Point(10, 123);
            this.btnDrawTree.Name = "btnDrawTree";
            this.btnDrawTree.Size = new System.Drawing.Size(150, 50);
            this.btnDrawTree.TabIndex = 4;
            this.btnDrawTree.Text = "Нарисовать дерево";
            this.btnDrawTree.UseVisualStyleBackColor = true;
            this.btnDrawTree.Click += new System.EventHandler(this.btnDrawTree_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 703);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Button btnLoadLSystem;
        private Button btnDrawFractal;
        private TextBox txtIterations;
        private PictureBox pictureBox;
        private Panel panel1;
        private Button btnDrawTree;
        private Label label1;
    }
}