using System.ComponentModel;

namespace lab5
{
    public partial class Form1 : Form
    {
        private List<PointF> points = new List<PointF>();
        //private List<PointF> midpoints = new List<PointF>();
        private List<PointF> steps = new List<PointF>();
        private Random rand = new Random();
        float r = 0.5f;
        float st = 3;
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            pictureBox1.BackColor = Color.White;
        }

        private void start_Click_1(object sender, EventArgs e)
        {
            //midpoints.Add(points[0]);
            //midpoints.Add(points[1]);
            steps.Clear();
            steps.Add(points[0]);
            steps.Add(points[1]);
            if (points.Count == 2)
            {
                using (Graphics g = Graphics.FromImage(pictureBox1.Image))
                {
                    g.Clear(Color.White);
                    g.FillEllipse(Brushes.Red, points[0].X - 3, points[0].Y - 3, 6, 6);
                    g.FillEllipse(Brushes.Red, points[1].X - 3, points[1].Y - 3, 6, 6);

                }
                DrawMidpointDisplacement(points[0], points[1], r);
                pictureBox1.Invalidate();
            }
        }

        private void pictureBox1_MouseClick_1(object sender, MouseEventArgs e)
        {
            if (points.Count < 2)
            {
                points.Add(new PointF(e.X, e.Y));
                steps.Add(new PointF(e.X, e.Y));
                using (Graphics g = Graphics.FromImage(pictureBox1.Image))
                {
                    g.FillEllipse(Brushes.Red, e.X - 3, e.Y - 3, 6, 6);
                }
                pictureBox1.Invalidate();
            }
        }

        private void DrawMidpointDisplacement(PointF p1, PointF p2, float displacement)
        {
            if (Math.Abs(p1.X - p2.X) < st)
            {
                using (Graphics g = Graphics.FromImage(pictureBox1.Image))
                {
                    g.DrawLine(Pens.Black, p1, p2);
                }
                pictureBox1.Invalidate();
                return;
            }

            float l = Math.Abs(p1.X - p2.X);

            PointF midpoint = new PointF(
                (p1.X + p2.X) / 2,
                (p1.Y + p2.Y) / 2 + (float)(-displacement * l + rand.NextDouble() * 2 * displacement * l));

            //midpoints.Add(midpoint);

            DrawMidpointDisplacement(p1, midpoint, displacement);
            DrawMidpointDisplacement(midpoint, p2, displacement);
        }

        private void DrawMidpointDisplacementSteps(PointF p1, PointF p2, float displacement)
        {
            float l = Math.Abs(p1.X - p2.X);

            PointF midpoint = new PointF(
                (p1.X + p2.X) / 2,
                (p1.Y + p2.Y) / 2 + (float)(-displacement * l + rand.NextDouble() * 2 * displacement * l));

            steps.Add(midpoint);
            using (Graphics g = Graphics.FromImage(pictureBox1.Image))
            {
                //g.FillEllipse(Brushes.Red, midpoint.X - 3, midpoint.Y - 3, 6, 6);
                g.DrawLine(Pens.Black, p1, midpoint);
                g.DrawLine(Pens.Black, midpoint, p2);
            }
            pictureBox1.Invalidate();
        }

        private void clear_Click(object sender, EventArgs e)
        {
            points.Clear();
            //midpoints.Clear();
            using (Graphics g = Graphics.FromImage(pictureBox1.Image))
            {
                g.Clear(Color.White);
            }
            pictureBox1.Invalidate();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            float.TryParse(textBox1.Text, out r);
        }

        private void step_TextChanged(object sender, EventArgs e)
        {
            float.TryParse(step.Text, out st);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            steps.Sort((p1, p2) => p1.X.CompareTo(p2.X));
            using (Graphics g = Graphics.FromImage(pictureBox1.Image))
            {
                g.Clear(Color.White);
                g.FillEllipse(Brushes.Red, points[0].X - 3, points[0].Y - 3, 6, 6);
                g.FillEllipse(Brushes.Red, points[1].X - 3, points[1].Y - 3, 6, 6);

            }
            int sz = steps.Count;
            for(int i=0; i<sz-1; i++)
            {
                if (Math.Abs(steps[i].X - steps[i + 1].X) < st)
                    return;
                DrawMidpointDisplacementSteps(steps[i], steps[i+1], r);
            }
            pictureBox1.Invalidate();
        }
    }
}

//float l = (float)Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));